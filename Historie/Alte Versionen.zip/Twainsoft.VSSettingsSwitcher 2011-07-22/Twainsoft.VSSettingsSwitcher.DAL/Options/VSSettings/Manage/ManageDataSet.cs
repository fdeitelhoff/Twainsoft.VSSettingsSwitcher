﻿namespace Twainsoft.VSSettingsSwitcher.DAL.Options.VSSettings.Manage {
    
    
    public partial class ManageDataSet {
    }
}
namespace Twainsoft.VSSettingsSwitcher.DAL.Options.VSSettings.Manage {
    
    
    public partial class ManageDataSet {
    }
}
