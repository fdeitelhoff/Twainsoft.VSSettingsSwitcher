﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Twainsoft.VSSettingsSwitcher.GUI.Options.Base;

namespace Twainsoft.VSSettingsSwitcher.GUI.Options.VSSettings.Create
{
    public class CreateOptionsStore : BaseOptionsStore
    {
        public CreateOptionsStore()
        {
            OptionsPage = new CreateOptionsPage();
        }
    }
}
