﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Twainsoft.VSSettingsSwitcher.GUI.Options.Base;
using Twainsoft.VSSettingsSwitcher.DAL.Options.VSSettings.Manage;

namespace Twainsoft.VSSettingsSwitcher.GUI.Options.VSSettings.Manage
{
    public class ManageOptionsStore : BaseOptionsStore
    {
        internal ManageDataSet ManageDataSet { get; set; }

        public ManageOptionsStore()
        {
            OptionsPage = new ManageOptionsPage(this);

            LoadData();
        }

        public string GetSettingFileCount()
        {
            return ManageDataSet.ConfiguredSettings.Rows.Count.ToString();
        }

        private void LoadData()
        {
            ManageDataSet.ReadXml(@"C:\Test\SettingsSwitcher.config");
            ManageDataSet.AcceptChanges();
        }

        internal void SaveData()
        {
            ManageDataSet.AcceptChanges();
            ManageDataSet.WriteXml(@"C:\Test\SettingsSwitcher.config");
        }
    }
}
