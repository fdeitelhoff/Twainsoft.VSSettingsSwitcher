﻿namespace Twainsoft.VSSettingsSwitcher.GUI.Options.VSSettings.Manage
{
    partial class ManageOptionsPage
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.configuredSettings = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fileDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isOpenDefaultDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.manageDataSet = new Twainsoft.VSSettingsSwitcher.DAL.Options.VSSettings.Manage.ManageDataSet();
            this.addSetting = new System.Windows.Forms.Button();
            this.elementHost1 = new System.Windows.Forms.Integration.ElementHost();
            this.userControl11 = new Twainsoft.VSSettingsSwitcher.GUI.Options.VSSettings.Manage.UserControl1();
            ((System.ComponentModel.ISupportInitialize)(this.configuredSettings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.manageDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // configuredSettings
            // 
            this.configuredSettings.AllowUserToAddRows = false;
            this.configuredSettings.AllowUserToDeleteRows = false;
            this.configuredSettings.AllowUserToResizeRows = false;
            this.configuredSettings.AutoGenerateColumns = false;
            this.configuredSettings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.configuredSettings.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.fileDataGridViewTextBoxColumn,
            this.isOpenDefaultDataGridViewCheckBoxColumn});
            this.configuredSettings.DataMember = "ConfiguredSettings";
            this.configuredSettings.DataSource = this.manageDataSet;
            this.configuredSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.configuredSettings.Location = new System.Drawing.Point(0, 0);
            this.configuredSettings.Name = "configuredSettings";
            this.configuredSettings.ReadOnly = true;
            this.configuredSettings.RowHeadersVisible = false;
            this.configuredSettings.RowTemplate.ReadOnly = true;
            this.configuredSettings.Size = new System.Drawing.Size(393, 76);
            this.configuredSettings.TabIndex = 0;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn.Visible = false;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fileDataGridViewTextBoxColumn
            // 
            this.fileDataGridViewTextBoxColumn.DataPropertyName = "File";
            this.fileDataGridViewTextBoxColumn.HeaderText = "File";
            this.fileDataGridViewTextBoxColumn.Name = "fileDataGridViewTextBoxColumn";
            this.fileDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // isOpenDefaultDataGridViewCheckBoxColumn
            // 
            this.isOpenDefaultDataGridViewCheckBoxColumn.DataPropertyName = "IsOpenDefault";
            this.isOpenDefaultDataGridViewCheckBoxColumn.HeaderText = "IsOpenDefault";
            this.isOpenDefaultDataGridViewCheckBoxColumn.Name = "isOpenDefaultDataGridViewCheckBoxColumn";
            this.isOpenDefaultDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // manageDataSet
            // 
            this.manageDataSet.DataSetName = "ManageDataSet";
            this.manageDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // addSetting
            // 
            this.addSetting.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.addSetting.Location = new System.Drawing.Point(318, 260);
            this.addSetting.Name = "addSetting";
            this.addSetting.Size = new System.Drawing.Size(75, 23);
            this.addSetting.TabIndex = 1;
            this.addSetting.Text = "Add";
            this.addSetting.UseVisualStyleBackColor = true;
            this.addSetting.Click += new System.EventHandler(this.addSetting_Click);
            // 
            // elementHost1
            // 
            this.elementHost1.Location = new System.Drawing.Point(38, 94);
            this.elementHost1.Name = "elementHost1";
            this.elementHost1.Size = new System.Drawing.Size(288, 160);
            this.elementHost1.TabIndex = 2;
            this.elementHost1.Text = "elementHost1";
            this.elementHost1.Child = this.userControl11;
            // 
            // ManageOptionsPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.elementHost1);
            this.Controls.Add(this.addSetting);
            this.Controls.Add(this.configuredSettings);
            this.Name = "ManageOptionsPage";
            ((System.ComponentModel.ISupportInitialize)(this.configuredSettings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.manageDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView configuredSettings;
        private System.Windows.Forms.Button addSetting;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fileDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isOpenDefaultDataGridViewCheckBoxColumn;
        private DAL.Options.VSSettings.Manage.ManageDataSet manageDataSet;
        private System.Windows.Forms.Integration.ElementHost elementHost1;
        private UserControl1 userControl11;
    }
}
