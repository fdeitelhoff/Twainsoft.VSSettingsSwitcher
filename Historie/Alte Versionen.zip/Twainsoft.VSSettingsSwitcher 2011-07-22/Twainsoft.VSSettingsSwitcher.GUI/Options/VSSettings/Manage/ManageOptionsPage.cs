﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Twainsoft.VSSettingsSwitcher.GUI.Options.Base;
using Twainsoft.VSSettingsSwitcher.DAL.Options.VSSettings.Manage;

namespace Twainsoft.VSSettingsSwitcher.GUI.Options.VSSettings.Manage
{
    public partial class ManageOptionsPage : BaseOptionsPage
    {
        private ManageOptionsStore ManageOptionsStore { get; set; }

        public ManageOptionsPage(ManageOptionsStore manageOptionsStore)
        {
            InitializeComponent();

            ManageOptionsStore = manageOptionsStore;
            ManageOptionsStore.ApplySettings += new BaseOptionsStore.ApplySettingsDelegate(ManageOptionsStore_ApplySettings);

            ManageOptionsStore.ManageDataSet = manageDataSet;
        }

        void ManageOptionsStore_ApplySettings(object sender, EventArgs e)
        {
            configuredSettings.EndEdit();

            ManageOptionsStore.SaveData();
        }
        
        private void addSetting_Click(object sender, EventArgs e)
        {
            ManageDataSet.ConfiguredSettingsRow newRow = manageDataSet.ConfiguredSettings.NewConfiguredSettingsRow();
            newRow.ID = Guid.NewGuid();
            newRow.Name = "Test1";
            newRow.File = "NoNewLines";
            newRow.IsOpenDefault = true;

            ManageDataSet.ConfiguredSettingsRow newRow2 = manageDataSet.ConfiguredSettings.NewConfiguredSettingsRow();
            newRow2.ID = Guid.NewGuid();
            newRow2.Name = "Test2";
            newRow2.File = "WithNewLines";
            newRow2.IsOpenDefault = false;

            manageDataSet.ConfiguredSettings.AddConfiguredSettingsRow(newRow);
            manageDataSet.ConfiguredSettings.AddConfiguredSettingsRow(newRow2);

            UserControl1 uc1 = elementHost1.Child as UserControl1;
            uc1.button1.Content = "Ich wurde gedrückt!";
        }
    }
}
