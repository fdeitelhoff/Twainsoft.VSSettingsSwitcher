﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Shell;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Twainsoft.VSSettingsSwitcher.GUI.Options.General;
using System.Windows.Forms;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Settings;
using Microsoft.VisualStudio.Shell.Settings;
using System.Diagnostics;
using Twainsoft.VSSettingsSwitcher.GUI.Options.Base;

namespace Twainsoft.VSSettingsSwitcher.GUI.Options
{
    public class GeneralOptionsStore : BaseOptionsStore
    {
        public string OptionInteger { get; set; }

        public GeneralOptionsStore()
        {
            OptionsPage = new GeneralOptionsPage(this);
        }
    }
}
