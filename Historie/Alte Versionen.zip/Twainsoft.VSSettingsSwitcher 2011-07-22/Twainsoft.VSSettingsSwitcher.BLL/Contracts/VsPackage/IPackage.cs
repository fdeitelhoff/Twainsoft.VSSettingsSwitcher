﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Twainsoft.VSSettingsSwitcher.BLL.Contracts.VsPackage
{
    public interface IPackage
    {
        K GetVsPackageService<T, K>() where K : class;
    }
}
