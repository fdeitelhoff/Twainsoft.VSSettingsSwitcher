﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Twainsoft.VSSettingsSwitcher.BLL.Contracts.Settings.Export
{
    public interface ISettingsExporter
    {
        void In_ExportSettings(string fileName);

        event Action<ISettingsExportedMessage> Out_SettingsExported;
    }
}
