﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Twainsoft.VSSettingsSwitcher.BLL.Contracts.Settings.Activate;
using Twainsoft.VSSettingsSwitcher.BLL.Components.Settings.Activate;
using System.Data;
using Twainsoft.VSSettingsSwitcher.DAL.Options.VSSettings.Manage;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Shell;
using Twainsoft.VSSettingsSwitcher.BLL.Contracts.StatusBar;
using Twainsoft.VSSettingsSwitcher.BLL.Components.StatusBar;
using Twainsoft.VSSettingsSwitcher.BLL.Options.VSSettings.Manage;
using Twainsoft.VSSettingsSwitcher.BLL.Components.Documents;
using Twainsoft.VSSettingsSwitcher.BLL.Options;
using Twainsoft.VSSettingsSwitcher.Utility.Messages;

namespace Twainsoft.VSSettingsSwitcher.GUI.ToolWindows.Settings
{
    public partial class SettingSwitcherControl : UserControl
    {
        private ManageOptionsStore ManageOptionsStore { get; set; }
        private ISettingsActivator SettingsActivator { get; set; }
        private IStatusBarUpdater StatusBarUpdater { get; set; }

        public SettingSwitcherControl()
        {
            InitializeComponent();

            SettingsActivator = new SettingsActivator();
            SettingsActivator.Out_SettingsActivatedMessage += new Action<ISettingsActivatedMessage>(SettingsActivator_Out_SettingsActivatedMessage);

            StatusBarUpdater = new StatusBarUpdater();
        }

        void SettingsActivator_Out_SettingsActivatedMessage(ISettingsActivatedMessage settingsActivatedMessage)
        {
            if (settingsActivatedMessage.Success)
            {
                StatusBarUpdater.In_UpdateStatusBar("The settings in the file '" + settingsActivatedMessage.FileName + "' were successfully loaded!");
            } 
            else if (!settingsActivatedMessage.Found)
            {
                StatusBarUpdater.In_UpdateStatusBar("The file '" + settingsActivatedMessage.FileName + "' could not be found!");

                VSMessageBox.ShowErrorMessageBox("Settings could not be loaded!",
                    "The file '" + settingsActivatedMessage.FileName + "' could not be found! Please check the settings!");
            }
        }

        public void SetDialogPage(ManageOptionsStore manageOptionsStore)
        {
            ManageOptionsStore = manageOptionsStore;
            settingsFilesOverview.ItemsSource = ManageOptionsStore.ManageDataSet.ConfiguredSettings.DefaultView;
        }

        private void activateSelectedSettings_Click(object sender, RoutedEventArgs e)
        {
            ActivateSettingsFile();
        }

        private void settingsFilesOverview_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ActivateSettingsFile();
        }

        private void ActivateSettingsFile()
        {
            DataRowView dataRow = settingsFilesOverview.SelectedItem as DataRowView;
            ManageDataSet.ConfiguredSettingsRow settingsRow = dataRow.Row as ManageDataSet.ConfiguredSettingsRow;

            SettingsActivator.In_ActivateSettings(settingsRow.File);
        }

        public void SetGeneralOptions(GeneralOptionsStore generalOptionsStore)
        {
            SettingsActivator.SetGeneralOptions(generalOptionsStore);
        }
    }
}
