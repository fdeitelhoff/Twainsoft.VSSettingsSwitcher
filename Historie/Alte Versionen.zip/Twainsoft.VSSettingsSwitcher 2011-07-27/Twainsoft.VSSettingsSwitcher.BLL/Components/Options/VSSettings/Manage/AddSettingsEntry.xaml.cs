﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.ComponentModel;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Shell;
using System.IO;
using Twainsoft.VSSettingsSwitcher.Utility.Messages;

namespace Twainsoft.VSSettingsSwitcher.BLL.Components.Options.VSSettings.Manage
{
    public partial class AddSettingsEntry : Window
    {
        private OpenFileDialog OpenFileDialog { get; set; }
        private string DefaultSettingsLocation { get; set; }

        public delegate void AddNewSettingsEntryEventHandler(object sender, AddNewSettingsEntryEventArgs e);
        public event AddNewSettingsEntryEventHandler AddNewSettingsEntry;

        public AddSettingsEntry()
        {
            InitializeComponent();

            IVsProfileDataManager profileDataManager = Package.GetGlobalService(typeof(SVsProfileDataManager)) as IVsProfileDataManager;

            string settingsPath = null;
            string settingsFileExtension = ".vssettings";
            profileDataManager.GetDefaultSettingsLocation(out settingsPath);
            profileDataManager.GetSettingsFileExtension(out settingsFileExtension);

            DefaultSettingsLocation = settingsPath;

            OpenFileDialog = new OpenFileDialog();
            OpenFileDialog.Multiselect = false;
            OpenFileDialog.DefaultExt = settingsFileExtension;
            OpenFileDialog.AddExtension = true;
            OpenFileDialog.InitialDirectory = settingsPath;
            OpenFileDialog.CheckFileExists = true;
            OpenFileDialog.CheckPathExists = true;
            OpenFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(openFileDialog_FileOk);
        }

        private void selectFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog.ShowDialog(this);
        }

        void openFileDialog_FileOk(object sender, CancelEventArgs e)
        {
            fileName.Text = OpenFileDialog.FileName;
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void buttonOK_Click(object sender, RoutedEventArgs e)
        {
            bool valid = !String.IsNullOrEmpty(name.Text.Trim());

            if (!valid)
            {
                VSMessageBox.ShowErrorMessageBox("Invalid name!",
                    "The specified name is not valid.");

                return;
            }

            FileInfo fileInfo = null;
            try
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(fileName.Text.Trim());

                fileInfo = new FileInfo(directoryInfo.FullName);

                if (!directoryInfo.FullName.ToLower().Contains(DefaultSettingsLocation.ToLower()))
                {
                    File.Copy(directoryInfo.FullName, System.IO.Path.Combine(DefaultSettingsLocation, fileInfo.Name));
                }
            }
            catch (ArgumentException)
            {
                valid = false;

                VSMessageBox.ShowErrorMessageBox("Invalid directory!",
                    "The specified directory '" + fileName.Text.Trim() + "' is not valid.");
            }
            catch (NotSupportedException)
            {
                valid = false;

                VSMessageBox.ShowErrorMessageBox("Invalid directory!", 
                    "The specified directory '" + fileName.Text.Trim() + "' is not valid.");
            }

            if (valid)
            {
                OnAddSettingsEntry(new AddNewSettingsEntryEventArgs(name.Text.Trim(), fileInfo.Name.Replace(fileInfo.Extension, "")));

                Close();
            }            
        }

        protected virtual void OnAddSettingsEntry(AddNewSettingsEntryEventArgs e)
        {
            if (AddNewSettingsEntry != null)
            {
                AddNewSettingsEntry(this, e);
            }
        }
    }
}
