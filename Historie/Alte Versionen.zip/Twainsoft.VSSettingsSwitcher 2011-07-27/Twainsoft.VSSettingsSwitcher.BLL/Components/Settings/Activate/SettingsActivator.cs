﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Twainsoft.VSSettingsSwitcher.BLL.Contracts.Settings.Activate;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Shell;
using System.Runtime.InteropServices;
using Twainsoft.VSSettingsSwitcher.BLL.Options.VSSettings.Manage;
using Twainsoft.VSSettingsSwitcher.BLL.Options;
using Twainsoft.VSSettingsSwitcher.BLL.Contracts.Documents;
using Twainsoft.VSSettingsSwitcher.BLL.Components.Documents;

namespace Twainsoft.VSSettingsSwitcher.BLL.Components.Settings.Activate
{
    public class SettingsActivator : ISettingsActivator
    {
        private IDocumentFormatter DocumentFormatter { get; set; }
        private IDocumentSaver DocumentSaver { get; set; }

        private GeneralOptionsStore GeneralOptionsStore { get; set; }

        public SettingsActivator()
        {
            DocumentFormatter = new DocumentFormatter();
            DocumentSaver = new DocumentSaver();
        }

        public void In_ActivateSettings(string fileName)
        {
            IVsProfileDataManager dm = (IVsProfileDataManager)Package.GetGlobalService(typeof(SVsProfileDataManager));

            IVsProfileSettingsTree sets;
            IVsProfileSettingsTree wl;

            IVsProfileSettingsFileCollection col;
            dm.GetSettingsFiles((uint)__VSPROFILELOCATIONS.PFL_SettingsDir, out col);

            int setFiles = 0;
            col.GetCount(out setFiles);

            IVsProfileSettingsFileInfo prfInfo = null;
            string filePath = null;
            bool found = false;
            for (int i = 0; i < setFiles; i++)
            {
                col.GetSettingsFile(i, out prfInfo);

                prfInfo.GetFilePath(out filePath);

                if (filePath.Contains(fileName))
                {
                    found = true;
                    break;
                }
                else
                {
                    filePath = null;
                }
            }

            bool success = false;
            if (!found)
            {
                OnSettingsActivatedMessage(new SettingsActivatedMessage(fileName, success, found));
                return;
            }

            prfInfo.GetSettingsForImport(out sets);
            IVsSettingsErrorInformation ret;

            int retCode = dm.ImportSettings(sets, out ret);

            Exception ex = Marshal.GetExceptionForHR(retCode);
            int pnErrors = 0;

            if (ex != null)
            {
                ret.GetErrorCount(out pnErrors);
            }
            else
            {
                success = true;
            }

            if (success && GeneralOptionsStore.AutoFormatDocumentsOnSettingsChanged)
            {
                DocumentFormatter.In_FormatAllOpenDocuments();

                if (GeneralOptionsStore.AutoSaveAllDocuments)
                {
                    DocumentSaver.In_SaveAllOpenDocuments();
                }
            }

            OnSettingsActivatedMessage(new SettingsActivatedMessage(fileName, success, found));
        }

        public event Action<ISettingsActivatedMessage> Out_SettingsActivatedMessage;

        protected virtual void OnSettingsActivatedMessage(ISettingsActivatedMessage settingsActivatedMessage)
        {
            if (Out_SettingsActivatedMessage != null)
            {
                Out_SettingsActivatedMessage(settingsActivatedMessage);
            }
        }

        public void SetGeneralOptions(GeneralOptionsStore generalOptionsStore)
        {
            GeneralOptionsStore = generalOptionsStore;
        }
    }
}
