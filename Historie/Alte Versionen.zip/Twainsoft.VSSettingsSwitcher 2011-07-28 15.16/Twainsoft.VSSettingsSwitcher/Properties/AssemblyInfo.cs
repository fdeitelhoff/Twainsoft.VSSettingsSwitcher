﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Settings-Switcher")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Twainsoft")]
[assembly: AssemblyProduct("Settings-Switcher")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]   
[assembly: ComVisible(false)]     
[assembly: CLSCompliant(false)]
[assembly: NeutralResourcesLanguage("en-US")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: InternalsVisibleTo("Twainsoft.VSSettingsSwitcher_IntegrationTests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100bbaea3410940289aab89016fa27f332f47400375cca1921bcc0a01e7040e11715fc679826c0fa846175f67701bc9b36d18485bf4497eea2fc9bc94c8973a3d2b8d929e813f6ea90589c8f3e0d3f9fbd6e503d910bd128712d30d90bf2504f3771a49f6c48431cc34ac6c37c1f99aad19dedaf2f2a4f0f9e180867f20a10f75a1")]
[assembly: InternalsVisibleTo("Twainsoft.VSSettingsSwitcher_UnitTests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100bbaea3410940289aab89016fa27f332f47400375cca1921bcc0a01e7040e11715fc679826c0fa846175f67701bc9b36d18485bf4497eea2fc9bc94c8973a3d2b8d929e813f6ea90589c8f3e0d3f9fbd6e503d910bd128712d30d90bf2504f3771a49f6c48431cc34ac6c37c1f99aad19dedaf2f2a4f0f9e180867f20a10f75a1")]
