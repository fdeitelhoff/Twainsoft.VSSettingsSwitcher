﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Twainsoft.VSSettingsSwitcher.BLL.Contracts.Settings.Export;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Shell;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.IO;

namespace Twainsoft.VSSettingsSwitcher.BLL.Components.Settings.Export
{
    public class SettingsExporter : ISettingsExporter
    {
        public SettingsExporter()
        {

        }

        public void In_ExportSettings(string fileName)
        {
            IVsProfileDataManager profileDataManager = Package.GetGlobalService(typeof(SVsProfileDataManager)) as IVsProfileDataManager;

            IVsSettingsErrorInformation settingsErrorInfo;

            int exportResult = profileDataManager.ExportAllSettings(fileName, out settingsErrorInfo);

            Exception ex = Marshal.GetExceptionForHR(exportResult);
            int pnErrors = 0;

            bool success = false;
            if (ex != null)
            {
                settingsErrorInfo.GetErrorCount(out pnErrors);
            }
            else
            {
                success = true;
            }

            Out_SettingsExported(new SettingsExportedMessage(fileName, success));
        }

        public event Action<ISettingsExportedMessage> Out_SettingsExported;
    }
}
