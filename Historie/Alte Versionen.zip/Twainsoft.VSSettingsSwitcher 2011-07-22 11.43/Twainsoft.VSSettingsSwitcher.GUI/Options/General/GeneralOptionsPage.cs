﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Twainsoft.VSSettingsSwitcher.GUI.Options.General
{
    public partial class GeneralOptionsPage : UserControl
    {
        private GeneralOptionsStore OptionsStore { get; set; }

        public GeneralOptionsPage(GeneralOptionsStore optionsStore)
        {
            OptionsStore = optionsStore;
            OptionsStore.ApplySettings += new Base.BaseOptionPage.ApplySettingsDelegate(OptionsStore_ApplySettings);

            InitializeComponent();

            textBox1.Text = OptionsStore.OptionInteger;
        }

        void OptionsStore_ApplySettings(object sender, EventArgs e)
        {
            OptionsStore.OptionInteger = textBox1.Text.Trim();
        }
    }
}
