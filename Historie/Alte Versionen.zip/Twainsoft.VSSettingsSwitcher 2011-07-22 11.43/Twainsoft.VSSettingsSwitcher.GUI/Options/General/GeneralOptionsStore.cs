﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Shell;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Twainsoft.VSSettingsSwitcher.GUI.Options.General;
using System.Windows.Forms;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Settings;
using Microsoft.VisualStudio.Shell.Settings;
using System.Diagnostics;
using Twainsoft.VSSettingsSwitcher.GUI.Options.Base;

namespace Twainsoft.VSSettingsSwitcher.GUI.Options
{
    public class GeneralOptionsStore : BaseOptionPage
    {
        private GeneralOptionsPage GeneralOptionsPage { get; set; }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected override IWin32Window Window
        {
            get
            {
                return GeneralOptionsPage = new GeneralOptionsPage(this);
            }
        }

        //[Category("My Options")]
        //[DisplayName("Integer Option")]
        //[Description("My integer option")]
        public string OptionInteger { get; set; }



        //public override void LoadSettingsFromStorage()
        //{
        //    OptionInteger = Settings.Default.FabisSetting;
        //}

        //public override void SaveSettingsToStorage()
        //{
            
        //}

        //public override void LoadSettingsFromXml(IVsSettingsReader reader)
        //{
        //    string value = "";
        //    reader.ReadSettingString("FabisSetting", out value);
        //    Trace.WriteLine("FabisSetting: " + value);
        //    OptionInteger = value;
        //}

        //public override void SaveSettingsToXml(IVsSettingsWriter writer)
        //{
        //    Trace.WriteLine("FabisSetting: " + OptionInteger);
        //    writer.WriteSettingString("FabisSetting", OptionInteger);
        //}
    }
}
