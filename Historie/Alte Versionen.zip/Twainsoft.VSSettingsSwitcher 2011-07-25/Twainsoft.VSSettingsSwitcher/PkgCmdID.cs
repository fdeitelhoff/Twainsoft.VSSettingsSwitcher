﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace Twainsoft.Twainsoft_VSSettingsSwitcher
{
    static class PkgCmdIDList
    {
        public const uint cmdidMyCommand =        0x100;
        public const uint cmdidMyTool =    0x101;
        public const uint myNewToolbarCommand =    0x1051;
    };
}