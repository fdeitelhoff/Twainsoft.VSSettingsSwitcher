﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Twainsoft.VSSettingsSwitcher.BLL.Options.Base;

namespace Twainsoft.VSSettingsSwitcher.BLL.Options.General
{
    public partial class GeneralOptionsPage : BaseOptionsPage
    {
        private GeneralOptionsStore GeneralOptionsStore { get; set; }

        public GeneralOptionsPage(GeneralOptionsStore generalOptionsStore)
        {
            GeneralOptionsStore = generalOptionsStore;

            InitializeComponent();

            LoadData();
        }

        private void LoadData()
        {
            autoFormatOpeningDocuments.Checked = GeneralOptionsStore.AutoFormatOpeningDocuments;
            autoSaveDocuments.Checked = GeneralOptionsStore.AutoSaveOpeningDocuments;

            formatAllOpenDocuments.Checked = GeneralOptionsStore.AutoFormatDocumentsOnSettingsChanged;
            saveAllOpenDocuments.Checked = GeneralOptionsStore.AutoSaveAllDocuments;
        }

        private void autoFormatOpenedDocuments_CheckedChanged(object sender, EventArgs e)
        {
            GeneralOptionsStore.AutoFormatOpeningDocuments = autoFormatOpeningDocuments.Checked;
            autoSaveDocuments.Enabled = GeneralOptionsStore.AutoFormatOpeningDocuments;
        }

        private void autoSaveDocuments_CheckedChanged(object sender, EventArgs e)
        {
            GeneralOptionsStore.AutoSaveOpeningDocuments = autoSaveDocuments.Checked;
        }

        private void formatAllOpenDocuments_CheckedChanged(object sender, EventArgs e)
        {
            GeneralOptionsStore.AutoFormatDocumentsOnSettingsChanged = formatAllOpenDocuments.Checked;
            saveAllOpenDocuments.Enabled = GeneralOptionsStore.AutoFormatDocumentsOnSettingsChanged;
        }

        private void saveAllOpenDocuments_CheckedChanged(object sender, EventArgs e)
        {
            GeneralOptionsStore.AutoSaveAllDocuments = saveAllOpenDocuments.Checked;
        }
    }
}
