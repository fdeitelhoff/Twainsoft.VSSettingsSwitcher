﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Shell;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.ComponentModel;

namespace Twainsoft.VSSettingsSwitcher.BLL.Options.Base
{
    [ClassInterface(ClassInterfaceType.AutoDual)]
    [Guid("b16c8b55-1eb6-4b1d-9061-3c172e93e186")]
    public class BaseOptionsStore : DialogPage
    {
        protected BaseOptionsPage OptionsPage { get; set; }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected override IWin32Window Window
        {
            get
            {
                return OptionsPage;
            }
        }

        public delegate void ApplySettingsDelegate(object sender, EventArgs e);
        public event ApplySettingsDelegate ApplySettings;

        protected override void OnApply(DialogPage.PageApplyEventArgs e)
        {
            OnApplySettings(EventArgs.Empty);

            base.OnApply(e);
        }

        protected virtual void OnApplySettings(EventArgs eventArgs)
        {
            if (ApplySettings != null)
            {
                ApplySettings(this, eventArgs);
            }
        }
    }
}
