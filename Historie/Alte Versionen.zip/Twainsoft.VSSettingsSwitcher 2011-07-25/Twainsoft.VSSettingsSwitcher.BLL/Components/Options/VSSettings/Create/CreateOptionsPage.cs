﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Twainsoft.VSSettingsSwitcher.BLL.Options.Base;
using Twainsoft.VSSettingsSwitcher.BLL.Components.Settings.Export;
using Twainsoft.VSSettingsSwitcher.BLL.Contracts.Settings.Export;

namespace Twainsoft.VSSettingsSwitcher.BLL.Options.VSSettings.Create
{
    public partial class CreateOptionsPage : BaseOptionsPage
    {
        private ISettingsExporter SettingsExporter { get; set; }

        public CreateOptionsPage()
        {
            InitializeComponent();

            SettingsExporter = new SettingsExporter();
            SettingsExporter.Out_SettingsExported += new Action<ISettingsExportedMessage>(SettingsExporter_Out_SettingsExported);
        }

        void SettingsExporter_Out_SettingsExported(ISettingsExportedMessage settingsExportedMessage)
        {
            MessageBox.Show("Exported: " + settingsExportedMessage.Success);
        }

        private void saveSettings_Click(object sender, EventArgs e)
        {
            SettingsExporter.In_ExportSettings("FabisTest");
        }
    }
}
