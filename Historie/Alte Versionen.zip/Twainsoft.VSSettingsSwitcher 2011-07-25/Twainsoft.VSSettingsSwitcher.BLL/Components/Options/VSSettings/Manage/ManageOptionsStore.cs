﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Twainsoft.VSSettingsSwitcher.BLL.Options.Base;
using Twainsoft.VSSettingsSwitcher.DAL.Options.VSSettings.Manage;
using System.IO;
using System.Data;

namespace Twainsoft.VSSettingsSwitcher.BLL.Options.VSSettings.Manage
{
    public class ManageOptionsStore : BaseOptionsStore
    {
        public ManageDataSet ManageDataSet { get; internal set; }

        public ManageOptionsStore()
        {
            OptionsPage = new ManageOptionsPage(this);

            LoadData();
        }

        public string GetSettingFileCount()
        {
            return ManageDataSet.ConfiguredSettings.Rows.Count.ToString();
        }

        private void LoadData()
        {
            if (File.Exists((@"C:\Test\SettingsSwitcher.config")))
            {
                try
                {
                    ManageDataSet.ReadXml(@"C:\Test\SettingsSwitcher.config");
                    ManageDataSet.AcceptChanges();
                }
                catch (ConstraintException constraintException)
                {
                    System.Windows.Forms.MessageBox.Show("Fehler beim Laden: " + constraintException);
                }
            }
        }

        private void SaveData()
        {
            ManageDataSet.AcceptChanges();
            ManageDataSet.WriteXml(@"C:\Test\SettingsSwitcher.config");
        }

        protected override void OnApplySettings(EventArgs eventArgs)
        {
            base.OnApplySettings(eventArgs);

            SaveData();
        }
    }
}
