﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Twainsoft.VSSettingsSwitcher.DAL.Options.VSSettings.Manage;

namespace Twainsoft.VSSettingsSwitcher.BLL.Options.VSSettings.Manage
{
    public partial class SettingsFilesOverview : UserControl
    {
        private ManageDataSet ManageDataSet { get; set; }

        public SettingsFilesOverview()
        {
            InitializeComponent();
        }

        public void SetDataContext(ManageDataSet manageDataSet)
        {
            ManageDataSet = manageDataSet;
            listView1.DataContext = ManageDataSet.ConfiguredSettings.DefaultView;
        }

        private void addSettingsFile_Click(object sender, RoutedEventArgs e)
        {
            ManageDataSet.ConfiguredSettingsRow newRow = ManageDataSet.ConfiguredSettings.NewConfiguredSettingsRow();
            newRow.Name = "Test " + ManageDataSet.ConfiguredSettings.Rows.Count;
            newRow.File = "NoNewLines";
            newRow.IsOpenDefault = false;

            ManageDataSet.ConfiguredSettings.AddConfiguredSettingsRow(newRow);
        }
    }
}
