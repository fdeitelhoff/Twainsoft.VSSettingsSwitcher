﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Twainsoft.VSSettingsSwitcher.BLL.Contracts.Settings.Export;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Shell;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.IO;

namespace Twainsoft.VSSettingsSwitcher.BLL.Components.Settings.Export
{
    public class SettingsExporter : ISettingsExporter
    {
        public SettingsExporter()
        {

        }

        public void In_ExportSettings(string fileName)
        {
            IVsProfileDataManager profileDataManager = Package.GetGlobalService(typeof(SVsProfileDataManager)) as IVsProfileDataManager;

            IVsSettingsErrorInformation settingsErrorInfo;
            IVsProfileSettingsTree exportableSettings;
            
            profileDataManager.GetSettingsForExport(out exportableSettings);

            exportableSettings.SetEnabled(1, 1);
            //@"AutomationProperties\TextEditor\CSharp-Specific";
            IVsProfileSettingsTree childTree1;
            exportableSettings.FindChildTree(@"VSSettingsSwitcher_CreateVSSetting", out childTree1);
            childTree1.SetEnabled(0, 1);

            IVsProfileSettingsTree childTree2;
            exportableSettings.FindChildTree(@"VSSettingsSwitcher_General", out childTree2);
            childTree2.SetEnabled(0, 1);

            IVsProfileSettingsTree childTree3;
            exportableSettings.FindChildTree(@"VSSettingsSwitcher_ManageVSSettings", out childTree3);
            childTree3.SetEnabled(0, 1);

            //int exportResult = profileDataManager.ExportAllSettings(fileName, out settingsErrorInfo);
            int exportResult = profileDataManager.ExportSettings(fileName, exportableSettings, out settingsErrorInfo);

            Exception ex = Marshal.GetExceptionForHR(exportResult);
            int pnErrors = 0;

            bool success = false;
            if (ex != null)
            {
                settingsErrorInfo.GetErrorCount(out pnErrors);
            }
            else
            {
                success = true;
            }

            Out_SettingsExported(new SettingsExportedMessage(fileName, success));
        }

        public event Action<ISettingsExportedMessage> Out_SettingsExported;
    }
}
