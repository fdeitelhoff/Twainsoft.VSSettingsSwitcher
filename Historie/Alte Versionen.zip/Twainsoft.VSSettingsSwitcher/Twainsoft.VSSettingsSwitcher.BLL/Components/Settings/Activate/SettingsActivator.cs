﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Twainsoft.VSSettingsSwitcher.BLL.Contracts.Settings.Activate;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Shell;
using System.Runtime.InteropServices;
using Twainsoft.VSSettingsSwitcher.BLL.Options.VSSettings.Manage;
using Twainsoft.VSSettingsSwitcher.BLL.Options;
using Twainsoft.VSSettingsSwitcher.BLL.Contracts.Documents;
using Twainsoft.VSSettingsSwitcher.BLL.Components.Documents;
using Twainsoft.VSSettingsSwitcher.DAL.Options.VSSettings.Manage;

namespace Twainsoft.VSSettingsSwitcher.BLL.Components.Settings.Activate
{
    public class SettingsActivator : ISettingsActivator
    {
        private IDocumentFormatter DocumentFormatter { get; set; }
        private IDocumentSaver DocumentSaver { get; set; }

        private GeneralOptionsStore GeneralOptionsStore { get; set; }
        private ManageDataSet ManageDataSet { get; set; }

        public SettingsActivator()
        {
            DocumentFormatter = new DocumentFormatter();
            DocumentSaver = new DocumentSaver();
        }

        public void In_ActivateSettings(ManageDataSet.ConfiguredSettingsRow settingsRow)
        {
            IVsProfileDataManager dm = (IVsProfileDataManager)Package.GetGlobalService(typeof(SVsProfileDataManager));

            IVsProfileSettingsTree sets;
            IVsProfileSettingsFileInfo prfInfo = null;
            IVsProfileSettingsFileCollection col;

            dm.GetSettingsFiles((uint)__VSPROFILELOCATIONS.PFL_Other, out col);

            col.AddBrowseFile(settingsRow.File, out prfInfo);

            int setFiles = 0;
            col.GetCount(out setFiles);

            string filePath = null;
            bool found = false;
            string fileName = settingsRow.File;
            for (int i = 0; i < setFiles; i++)
            {
                col.GetSettingsFile(i, out prfInfo);

                prfInfo.GetFilePath(out filePath);

                if (filePath.Contains(fileName))
                {
                    found = true;
                    break;
                }
                else
                {
                    filePath = null;
                }
            }

            bool success = false;
            if (!found)
            {
                OnSettingsActivatedMessage(new SettingsActivatedMessage(fileName, success, found));
                return;
            }

            prfInfo.GetSettingsForImport(out sets);

            sets.SetEnabled(1, 1);
            //@"AutomationProperties\TextEditor\CSharp-Specific";
            IVsProfileSettingsTree childTree1;
            sets.FindChildTree(@"VSSettingsSwitcher_CreateVSSetting", out childTree1);
            if (childTree1 != null)
            {
                childTree1.SetEnabled(0, 1);
            }

            IVsProfileSettingsTree childTree2;
            sets.FindChildTree(@"VSSettingsSwitcher_General", out childTree2);
            if (childTree2 != null)
            {
                childTree2.SetEnabled(0, 1);
            }

            IVsProfileSettingsTree childTree3;
            sets.FindChildTree(@"VSSettingsSwitcher_ManageVSSettings", out childTree3);
            if (childTree3 != null)
            {
                childTree3.SetEnabled(0, 1);
            }            
            
            IVsSettingsErrorInformation ret;
            int retCode = dm.ImportSettings(sets, out ret);

            Exception ex = Marshal.GetExceptionForHR(retCode);
            int pnErrors = 0;

            if (ex != null)
            {
                ret.GetErrorCount(out pnErrors);
            }
            else
            {
                success = true;
            }

            if (success)
            {
                foreach (ManageDataSet.ConfiguredSettingsRow currentSettingsRow in ManageDataSet.ConfiguredSettings.Rows)
                {
                    if (currentSettingsRow == settingsRow)
                    {
                        currentSettingsRow.IsActive = true;
                    }
                    else if (currentSettingsRow.IsActive)
                    {
                        currentSettingsRow.IsActive = false;
                    }
                }

                if (GeneralOptionsStore.AutoFormatDocumentsOnSettingsChanged)
                {
                    DocumentFormatter.In_FormatAllOpenDocuments();

                    if (GeneralOptionsStore.AutoSaveAllDocuments)
                    {
                        DocumentSaver.In_SaveAllOpenDocuments();
                    }
                }
            }

            OnSettingsActivatedMessage(new SettingsActivatedMessage(fileName, success, found));
        }

        public event Action<ISettingsActivatedMessage> Out_SettingsActivatedMessage;

        protected virtual void OnSettingsActivatedMessage(ISettingsActivatedMessage settingsActivatedMessage)
        {
            if (Out_SettingsActivatedMessage != null)
            {
                Out_SettingsActivatedMessage(settingsActivatedMessage);
            }
        }

        public void SetGeneralOptions(GeneralOptionsStore generalOptionsStore)
        {
            GeneralOptionsStore = generalOptionsStore;
        }

        public void SetManageOptionsStore(ManageDataSet manageDataSet)
        {
            ManageDataSet = manageDataSet;
        }
    }
}
