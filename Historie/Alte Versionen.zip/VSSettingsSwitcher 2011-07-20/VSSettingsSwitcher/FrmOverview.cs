﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualStudio.Shell.Interop;

namespace VSSettingsSwitcher
{
    public partial class FrmOverview : Form
    {
        public FrmOverview()
        {
            InitializeComponent();
        }

        internal void FillTree(IVsProfileSettingsTree sets)
        {
            TreeNode parent = new TreeNode("Root");
            this.treeView1.Nodes.Add(parent);

            this.AddNode(sets, parent);

            parent.ExpandAll();
        }

        private void AddNode(IVsProfileSettingsTree sets, TreeNode parent)
        {
            string displayName = "";
            string pbstrRegisteredName = "";

            sets.GetDisplayName(out displayName);
            sets.GetRegisteredName(out pbstrRegisteredName);

            int childCount = 0;
            sets.GetChildCount(out childCount);

            TreeNode newNode = new TreeNode(displayName + "(" + pbstrRegisteredName + ") (Childs: " + childCount + ")");
            parent.Nodes.Add(newNode);
            
            for (int i = 0; i < childCount; i++)
            {
                IVsProfileSettingsTree childTree;
                sets.GetChild(i, out childTree);

                this.AddNode(childTree, newNode);
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            this.label1.Text = e.Node.FullPath;
        }
    }
}
