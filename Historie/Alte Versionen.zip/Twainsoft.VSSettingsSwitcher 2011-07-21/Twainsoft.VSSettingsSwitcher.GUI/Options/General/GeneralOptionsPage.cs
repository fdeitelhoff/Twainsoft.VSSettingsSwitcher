﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Twainsoft.VSSettingsSwitcher.GUI.Options.General
{
    public partial class GeneralOptionsPage : UserControl
    {
        private GeneralOptionsStore OptionsStore { get; set; }

        public GeneralOptionsPage(GeneralOptionsStore optionsStore)
        {
            OptionsStore = optionsStore;

            InitializeComponent();

            textBox1.Text = OptionsStore.OptionInteger;
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            throw new Exception("Kommt er hier hin?");
        }

        internal void SaveValues()
        {
            OptionsStore.OptionInteger = textBox1.Text.Trim();
            //System.Diagnostics.Trace.WriteLine(OptionsStore.OptionInteger);
            //MessageBox.Show(OptionsStore.OptionInteger);

            //return textBox1.Text.Trim();
        }
    }
}
