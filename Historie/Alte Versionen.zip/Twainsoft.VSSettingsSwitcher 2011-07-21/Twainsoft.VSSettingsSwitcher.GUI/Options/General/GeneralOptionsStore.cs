﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Shell;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Twainsoft.VSSettingsSwitcher.GUI.Options.General;
using System.Windows.Forms;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Settings;
using Microsoft.VisualStudio.Shell.Settings;

namespace Twainsoft.VSSettingsSwitcher.GUI.Options
{
    [ClassInterface(ClassInterfaceType.AutoDual)]
    [Guid("b16c8b55-1eb6-4b1d-9061-3c172e93e186")]
    public class GeneralOptionsStore : DialogPage
    {
        private GeneralOptionsPage GeneralOptionsPage { get; set; }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected override IWin32Window Window
        {
            get
            {
                return GeneralOptionsPage = new GeneralOptionsPage(this);
            }
        }

        //[Category("My Options")]
        //[DisplayName("Integer Option")]
        //[Description("My integer option")]
        internal string OptionInteger { get; set; }

        protected override void OnApply(DialogPage.PageApplyEventArgs e)
        {
            //base.OnApply(e);

            //MessageBox.Show("OnApply: " + e.ApplyBehavior.ToString());

            this.GeneralOptionsPage.SaveValues();
            //this.SaveSettingsToXml(userSettingsStore);
        }

        public override void LoadSettingsFromStorage()
        {
            Console.WriteLine("bla");
        }

        public override void LoadSettingsFromXml(IVsSettingsReader reader)
        {
            string value = "";
            reader.ReadSettingString("FabisSetting", out value);

            OptionInteger = value;
        }

        public override void SaveSettingsToXml(IVsSettingsWriter writer)
        {
            writer.WriteSettingString("FabisSetting", OptionInteger);
        }
    }
}
